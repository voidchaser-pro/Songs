package com.example.songcounter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

data class Song(val id: Long, val title: String, val artist: String, val plays: Int, val history: List<Long> = emptyList())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SongCounterApp() }
    }
}

@Composable
fun SongCounterApp() {
    var songs by remember { mutableStateOf(listOf<Song>()) }
    var query by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("🎵 Song Counter") }) },
            floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }) { Text("+") } }
        ) { pad ->
            Column(Modifier.padding(pad).padding(16.dp)) {
                OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("Search songs") })
                Spacer(Modifier.height(12.dp))
                if (songs.isEmpty()) Text("No songs yet. Tap + to add your first song.")
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(songs.filter { it.title.contains(query, true) || it.artist.contains(query, true) }) { song ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) {
                                    Text(song.title, style = MaterialTheme.typography.titleMedium)
                                    Text(song.artist)
                                    Text("${song.plays} plays")
                                }
                                Button(onClick = {
                                    songs = songs.map {
                                        if (it.id == song.id) it.copy(plays = it.plays + 1, history = it.history + System.currentTimeMillis()) else it
                                    }
                                }) { Text("+1 Played") }
                            }
                        }
                    }
                }
            }
        }

        if (showAdd) {
            AddSongDialog(
                onDismiss = { showAdd = false },
                onAdd = { title, artist ->
                    songs = songs + Song(System.currentTimeMillis(), title, artist, 0)
                    showAdd = false
                }
            )
        }
    }
}

@Composable
fun AddSongDialog(onDismiss: () -> Unit, onAdd: (String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Song") },
        text = {
            Column {
                OutlinedTextField(title, { title = it }, label = { Text("Song title") })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(artist, { artist = it }, label = { Text("Artist") })
            }
        },
        confirmButton = { Button(enabled = title.isNotBlank(), onClick = { onAdd(title, artist) }) { Text("Add") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
